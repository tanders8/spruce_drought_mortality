///////////////////////////////////////////////////////////////////////////////////////
/// \file spinupdata.cpp
/// \brief Management of climate data for spinup
///
/// $Date: 2019-02-08 15:55:08 +0100 (Fri, 08 Feb 2019) $
///
///////////////////////////////////////////////////////////////////////////////////////

#include "config.h"
#include "spinupdata.h"
#include "shell.h"



using std::vector;

GenericSpinupData::GenericSpinupData()
	: thisyear(0) {
}

void GenericSpinupData::get_data_from(RawData& source) {
	data = source;

	if (source.empty()) {
		fail("No source data given to GenericSpinupData::get_data_from()");
	}

	for (size_t i = 0; i < source.size(); ++i) {
		if ((source[i].size() != 12 &&
		     source[i].size() % DAYS_PER_YEAR != 0) ||
		    source[i].empty()) {
			fail("Incorrect number of timesteps per year in data given to\n"\
			     "GenericSpinupData (got %d)", source[i].size());
		}

		if (i > 0 && source[i].size() != source[i-1].size()) {
			fail("Different number of timesteps in different years in\n"\
			     "data given to GenericSpinupData::get_data_from()");
		}
	}
	
	firstyear();
}

double GenericSpinupData::operator[](int ts) const {
	if (ts < 0 || ts >= int(data[thisyear].size())) {
		fail("Trying to access data for timestep %d during spinup\n"\
		     "(should be 0-%d)", ts, data[thisyear].size());
	}
	return data[thisyear][ts];
}

void GenericSpinupData::nextyear() {
	thisyear = (thisyear + 1) % nbr_years();
}

void GenericSpinupData::firstyear() {
	thisyear = 0;
}

void GenericSpinupData::detrend_data() {

	vector<double> annual_mean(nbr_years(), 0);
	vector<double> year_number(nbr_years());

	for (size_t y = 0; y < nbr_years(); ++y) {
		for (size_t d = 0; d < data[y].size(); ++d) {
			annual_mean[y] += data[y][d];
		}
		annual_mean[y] /= data[y].size();
		year_number[y] = (double)y;
	}

	double a, b;
	regress(&year_number.front(), &annual_mean.front(), (int) nbr_years(), a, b);

	for (size_t y = 0; y < nbr_years(); ++y) {
		double anomaly = b*y;
		for (size_t d = 0; d < data[y].size(); ++d) {
			data[y][d] -= anomaly;
		}
	}
}

size_t GenericSpinupData::nbr_years() const {
	return data.size();
}

double* GenericSpinupData::calc_seasonal_longterm_mean_data()
{
	double* returnarray = new double [8];

	double winter_dsum[nbr_years()];
	double winter_mean[nbr_years()];
	double spring_dsum[nbr_years()];
	double spring_mean[nbr_years()];
	double summer_dsum[nbr_years()];
	double summer_mean[nbr_years()];
	double autumn_dsum[nbr_years()];
	double autumn_mean[nbr_years()];

	for (int i = 0; i < nbr_years(); i++) {
		winter_dsum[i] = 0;
		winter_mean[i] = 0;
		spring_dsum[i] = 0;
		spring_mean[i] = 0;
		summer_dsum[i] = 0;
		summer_mean[i] = 0;
		autumn_dsum[i] = 0;
		autumn_mean[i] = 0;
	}

	double winter_longterm_sum = 0;
	double winter_longterm_dsum = 0;
	double winter_longterm_mean = 0;


	double spring_longterm_sum = 0;
	double spring_longterm_dsum = 0;
	double spring_longterm_mean = 0;


	double summer_longterm_sum = 0;
	double summer_longterm_dsum = 0;
	double summer_longterm_mean = 0;


	double autumn_longterm_sum = 0;
	double autumn_longterm_dsum = 0;
	double autumn_longterm_mean = 0;


	for (size_t y = 0; y < nbr_years(); ++y) {
		for (size_t d = 0; d < data[y].size(); ++d) {
			if (y == 0 && d <= 333) {
				winter_dsum[y] = 0.0;
				spring_dsum[y] = 0.0;
				summer_dsum[y] = 0.0;
				autumn_dsum[y] = 0.0;
			}

			else if (y == 0 && d >= 334){
				winter_dsum[y] += data[y][d];
			}

			else if (y >= 1 && y < 30) {
				if ((d <= 58) || (d >= 334)) {
					winter_dsum[y] += data[y][d];
				}
				else if ((d > 58) && (d <= 150)) {
					spring_dsum[y] += data[y][d];
				}
				else if ((d > 150) && (d <= 242)) {
					summer_dsum[y] += data[y][d];
				}
				else if ((d > 242) && (d <= 333)){
					autumn_dsum[y] += data[y][d];
				}
			}

			else if (y == 30) {
				if ((d <= 58)) {
					winter_dsum[y] += data[y][d];
				}
				else if ((d > 58) && (d <= 150)) {
					spring_dsum[y] += data[y][d];
				}
				else if ((d > 150) && (d <= 242)) {
					summer_dsum[y] += data[y][d];
				}
				else if ((d > 242) && (d <= 333)){
					autumn_dsum[y] += data[y][d];
				}
			}
		}
		winter_mean[y] = winter_dsum[y] / 90;
		//dprintf("Seasonal winter value %i = %f\n", 1980+y, winter_mean[y]);
		winter_longterm_dsum += winter_mean[y];
		winter_longterm_sum += winter_dsum[y];

		spring_mean[y] = spring_dsum[y] / 92;
		//dprintf("Seasonal spring value %i = %f\n", 1980+y, spring_mean[y]);
		spring_longterm_dsum += spring_mean[y];
		spring_longterm_sum += spring_dsum[y];

		summer_mean[y] = summer_dsum[y] / 92;
		//dprintf("Seasonal summer value %i = %f\n", 1980+y, summer_mean[y]);
		summer_longterm_dsum += summer_mean[y];
		summer_longterm_sum += summer_dsum[y];

		autumn_mean[y] = autumn_dsum[y] / 91;
		//dprintf("Seasonal autumn value %i = %f\n", 1980+nbr_years(), autumn_mean[y]);
		autumn_longterm_dsum += autumn_mean[y];
		autumn_longterm_sum += autumn_dsum[y];

	}
	winter_longterm_mean = winter_longterm_dsum / 30;
	winter_longterm_sum = winter_longterm_sum / 30;

	spring_longterm_mean = spring_longterm_dsum / 30;
	spring_longterm_sum = spring_longterm_sum / 30;

	summer_longterm_mean = summer_longterm_dsum / 30;
	summer_longterm_sum = summer_longterm_sum / 30;

	autumn_longterm_mean = autumn_longterm_dsum / 30;
	autumn_longterm_sum = autumn_longterm_sum / 30;


	// long-term daily mean values
	returnarray[0] = winter_longterm_mean;
	//dprintf("Long term mean winter temp return array = %f\n", returnarray[0]);
	returnarray[1] = spring_longterm_mean;
	returnarray[2] = summer_longterm_mean;
	returnarray[3] = autumn_longterm_mean;

	// long-term seasonal sum values
	returnarray[4] = winter_longterm_sum;
	returnarray[5] = spring_longterm_sum;
	returnarray[6] = summer_longterm_sum;
	returnarray[7] = autumn_longterm_sum;

	return returnarray;
}

double* GenericSpinupData::calc_run_seasonal_longterm_mean_data()
{
	double* returnarray = new double [4];

		double summer_dsum[nbr_years()];
		double summer_mean[nbr_years()];
		double min_summer_dsum[nbr_years()];
		double max_summer_dsum_2yr[nbr_years()];
		double mean_summer_dsum_3yr[nbr_years()];
		double mean_summer_dsum_5yr[nbr_years()];
		double mean_summer_mean_5yr[nbr_years()];
		double max_summer_mean_2yr[nbr_years()];
		Historic<double, 5>summer_5_dsum;
		Historic<double, 5>summer_5_mean;
		Historic<double, 3>summer_3_dsum;
		Historic<double, 2>summer_2_mean;

		double summer_min_longterm_sum = 0;
		double summer_mean_longterm_3yr_sum = 0;
		double summer_mean_longterm_5yr_sum = 0;
		double summer_mean_longterm_5yr_mean = 0;
		double summer_max_longterm_2yr_sum = 0;
		double summer_max_longterm_2yr_mean = 0;

		for (int i = 0; i < nbr_years(); i++) {
			summer_dsum[i] = 0;
			summer_mean[i] = 0;
		}
		// Initialize 5yr storage variable
		for (int i = 0; i < summer_5_dsum.CAPACITY; i++) {
			summer_5_dsum.add(0);
		}
		// Initialize 3yr storage variable
		for (int i = 0; i < summer_3_dsum.CAPACITY; i++) {
				summer_3_dsum.add(0);
			}
		// Initialize 2yr storage variable
		for (int i = 0; i < summer_2_mean.CAPACITY; i++) {
					summer_2_mean.add(0);
				}

		// Initialize longterm variables variable
		double summer_longterm_sum = 0;
		double summer_longterm_dsum = 0;
		double summer_longterm_mean = 0;

		// fill daily sum with actual values
		for (size_t y = 0; y < nbr_years(); ++y) {
			for (size_t d = 0; d < data[y].size(); ++d) {
				if (y == 0 && d <= 333) {
					summer_dsum[y] = 0.0;
				}

				else if (y >= 1 && y < 30) {
					if ((d > 150) && (d <= 242)) {
						summer_dsum[y] += data[y][d];
					}
				}

				else if (y == 30) {
					if ((d > 150) && (d <= 242)) {
						summer_dsum[y] += data[y][d];
					}
				}
			}
		}
		// Initialize 3yr storage variable with values from 1981
		for (int i = 0; i < summer_3_dsum.CAPACITY; i++) {
					summer_3_dsum.add(summer_dsum[1]);
		}
		// Initialize 5yr storage variable with values from 1981
		for (int i = 0; i < summer_5_dsum.CAPACITY; i++) {
						summer_5_dsum.add(summer_dsum[1]);
		}
		// Initialize 5yr storage variable with values from 1981
		for (int i = 0; i < summer_5_mean.CAPACITY; i++) {
							summer_5_mean.add(summer_dsum[1]/92);
		}
		// Initialize 2yr storage variable with values from 1981
		for (int i = 0; i < summer_2_mean.CAPACITY; i++) {
			summer_2_mean.add(summer_dsum[1]/92);
		}


		for (size_t y = 0; y < nbr_years(); ++y){

			// 5yr minimum sum
			summer_5_dsum.add(summer_dsum[y]);
			min_summer_dsum[y] = summer_5_dsum.min();
			summer_min_longterm_sum += min_summer_dsum[y];

			summer_mean[y] = summer_dsum[y] / 92;

			// 5yr mean mean
			summer_5_mean.add(summer_mean[y]);
			mean_summer_mean_5yr[y] = summer_5_mean.mean();
			summer_mean_longterm_5yr_sum += mean_summer_mean_5yr[y];
		}

		// 3yr summer sum
		for (size_t y = 0; y < nbr_years(); ++y){
			summer_3_dsum.add(summer_dsum[y]);
			mean_summer_dsum_3yr[y] = summer_3_dsum.mean();
			summer_mean_longterm_3yr_sum += mean_summer_dsum_3yr[y];
		}

		// 2yr maximum mean
		for (size_t y = 1; y < nbr_years(); ++y){
			summer_mean[y] = summer_dsum[y] / 92;
			summer_2_mean.add(summer_mean[y]);
			max_summer_mean_2yr[y] = summer_2_mean.max();
			summer_max_longterm_2yr_sum += max_summer_mean_2yr[y];
		}

		// devide it by 30 years to get long-term mean value
		summer_min_longterm_sum = summer_min_longterm_sum/30;
		summer_mean_longterm_3yr_sum = summer_mean_longterm_3yr_sum/30;
		summer_mean_longterm_5yr_mean = summer_mean_longterm_5yr_sum/30;
		summer_max_longterm_2yr_mean = summer_max_longterm_2yr_sum/30;
		returnarray[0] = summer_max_longterm_2yr_mean;
		returnarray[1] = summer_mean_longterm_5yr_mean;
		returnarray[2] = summer_min_longterm_sum;
		returnarray[3] = summer_mean_longterm_3yr_sum;
		//dprintf("Long term mean summer rollmin return array = %f\n", returnarray[2]);
		//dprintf("Long term mean summer rollmean 3yr return array = %f\n", returnarray[3]);
		//dprintf("Long term mean summer rollmean 5yr return array = %f\n", returnarray[1]);
		//dprintf("Long term mean summer rollmax 2yr return array = %f\n", summer_max_longterm_2yr_mean);

		return returnarray;
}

void GenericSpinupData::calc_pet_climate(double lon, double lat, GenericSpinupData& spinup_temp, GenericSpinupData& spinup_insol) {

	double u[365];
	double v[365];
	double qo[365];
	double hh[365];
	double sinehh[365];

	const double QOO = 1360.0;
	const double BETA = 0.17;

	const double A = 107.0;
	const double B = 0.2;
	const double C = 0.25;
	const double D = 0.5;
	const double K = 13750.98708;

	const double DEGTORAD = PI / 180.;

	double sinelat = sin(lat * DEGTORAD);
	double cosinelat = cos(lat * DEGTORAD);

	/// Priestley-Taylor coefficient (conversion factor from equilibrium evapotranspiration to PET)
	const double PRIESTLEY_TAYLOR = 1.32;


	for (size_t y = 0; y < nbr_years(); ++y) {
			for (size_t d = 0; d < data[y].size(); ++d) {

				// Calculate values of saved parameters for this day
				qo[d] = QOO * (1.0 + 2.0 * 0.01675 * cos(2.0 * PI * (d + 0.5) / 365)); // Eqn 2
				double delta = -23.4 * DEGTORAD * cos(2.0 * PI * (d + 10.5) / 365);// Eqn 4, solar declination angle (radians)
				u[d] = sinelat * sin(delta); // Eqn 9
				v[d] = cosinelat * cos(delta); // Eqn 10
				hh[d] = acos(-u[d] / v[d]);
				sinehh[d] = sin(hh[d]);

				double averaging_period = 24 * 3600;
				double net_coeff = 1;

				net_coeff = 1 - BETA;

				double rad = spinup_insol.data[y][d] * net_coeff * averaging_period;

				double w = rad / 2.0 /(u[d] * hh[d] + v[d] * sinehh[d]) / K; // from Eqn 14

				//double w = (C+D * spinup_insol.data[y][d] / 100.0) * (1.0 - BETA) * qo[d]; // Eqn 13
				double rl = (B + (1.0 - B) * (w / qo[d] / (1.0 - BETA) - C) / D) * (A - (spinup_temp.data[y][d] - 273.15)); // Eqn 19: instantaneous net upward longwave radiation flux (W/m2)

				//	Calculate gamma and lambda
				double gamma = 65.05 + (spinup_temp.data[y][d] - 273.15) * 0.064;
				double lambda = 2.495e6 - (spinup_temp.data[y][d] - 273.15) * 2380.;

				double ct = 237.3 + (spinup_temp.data[y][d] - 273.15);
				double s = 2.503e6 * exp(17.269 * (spinup_temp.data[y][d] - 273.15) / ct) / ct / ct;		// Eqn 16

				double uu = w * u[d] - rl;			// Eqn 20
				double vv = w * v[d];				// Eqn 21

				// Calculate half-period with positive net radiation, hn
				// In Eqn (25), hn defined for uu in range -vv to vv
				// For uu >= vv, hn = pi (12 hours, i.e. polar day)
				// For uu <= -vv, hn = 0 (i.e. polar night)
				double hn;
				if (uu >= vv)  hn = PI; // polar day
				else if (uu <= -vv) hn = 0.0; // polar night
				else hn = acos(-uu / vv); // Eqn 25

				// Calculate total EET (equilibrium evapotranspiration) for this day, mm/day
				double eet = 2.0 * (s / (s + gamma) / lambda) * (uu * hn + vv * sin(hn)) * K;	// Eqn 26;
				data[y][d] = eet * PRIESTLEY_TAYLOR;	// Eqn 26;

				/*if (y <= 30) {
					dprintf("dpet = %f\n", data[y][d]);
													}*/

				}
			}
}

void GenericSpinupData::calc_cwb_climate(GenericSpinupData& spinup_prec, GenericSpinupData& spinup_pet) {
	for (size_t y = 0; y < nbr_years(); ++y) {
				for (size_t d = 0; d < data[y].size(); ++d) {
					data[y][d] = spinup_prec.data[y][d] - spinup_pet.data[y][d];
					/*if (y == 30) {
						dprintf("prec = %f\n", spinup_prec.data[y][d]);
						dprintf("pet_data = %f\n", spinup_pet.data[y][d]);
						dprintf("daily cwb = %f\n", data[y][d]);
								}*/
				}
	}
}
