guesswin.exe

Because of large size, from 4.0 and onwards, guesswin.exe is not stored in the svn repository.

Instead it can be dowloaded from here:

For release version 4.x, here is a direct link:
http://stormbringer.nateko.lu.se/download/f59d545c1a729/guess_download/guesswin.exe_release4.0.zip

For earlier versions of LPJ-GUESS, go to web page below, download the whole LPJ-GUESS package, and copy the guesswin.exe from the windows_version catalog of the package.
http://stormbringer.nateko.lu.se/download/f59d545c1a729/guess_download/

Please note:
The path to the direct link and the download page above is updated from time to time. There may be a lag until the path is updated here in this present file in svn. Therefore, if the path does not work for you, ask Johan for the new path to the download page and add /guesswin.exe_release4.0.zip to the end of the path to download guesswin.exe.
