NPROCESS=5
INPUT_MODULE=watch_diurnal
if [[ $ARCH == "aurora" ]]; then
    NPROCESS=10
fi

