NPROCESS=5
if [[ $ARCH == "aurora" ]]; then
    NPROCESS=10
fi
