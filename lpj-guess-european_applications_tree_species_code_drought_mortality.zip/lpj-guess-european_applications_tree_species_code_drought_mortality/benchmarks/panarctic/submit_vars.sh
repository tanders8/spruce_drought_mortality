NPROCESS=12
if [[ $ARCH == "aurora" ]]; then
    NPROCESS=40
fi
