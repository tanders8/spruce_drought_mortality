NPROCESS=24
if [[ $ARCH == "aurora" ]]
then
    NPROCESS=80
fi
